
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'toroduque',
  applicationName: 'guitar-chords-api',
  appUid: 'n0FNvtDRHhlgvNyY2X',
  orgUid: 'hx70n4bl9qrBbK8Nz8',
  deploymentUid: 'd0aadb67-e38a-4e94-9001-a39d7aefc36b',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.12',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}